import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todo-list-component',
  templateUrl: './todo-list-component.component.html',
  styleUrls: ['./todo-list-component.component.scss']
})
export class TodoListComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
