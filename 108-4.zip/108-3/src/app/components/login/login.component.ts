import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';
import { SharedService } from 'src/app/services/shared.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  username = "";
  password = "";
  isErrorVisible = false;


  constructor(private dataSrv: DataService, private shared: SharedService, private router: Router) { }

  ngOnInit(): void {
  }

  login() {
    var allUsers = this.dataSrv.getAllUsers();
    var found = false;
    for(let i=0; i < allUsers.length; i++) {
      var user = allUsers[i];

      if (this.username == user.userName && this.password == user.userPassword ) {
        found = true;
        console.log("User logged in", found);
        this.shared.isUserLoggedIn = true;
        this.shared.userName = user.userName;
        this.router.navigate(['/converter']);
      }
    }
    if(!found){
      this.isErrorVisible = true;
      setTimeout(()=> this.isErrorVisible = false, 3000);
    }
  }

}
