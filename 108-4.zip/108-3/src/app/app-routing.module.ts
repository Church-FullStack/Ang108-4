import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TodoListComponentComponent } from './components/todo-list-component/todo-list-component.component';
import { TempConverterComponent } from './components/temp-converter/temp-converter.component';
import { AboutComponent } from './components/about/about.component';
import { UserWizardComponent } from './components/user-wizard/user-wizard.component';
import { UserListComponent } from './components/user-list/user-list.component';
import { LoginComponent } from './components/login/login.component';


const routes: Routes = [
  { path: 'todo', component: TodoListComponentComponent},
  { path: 'converter', component: TempConverterComponent},
  { path: 'about', component: AboutComponent},
  { path: 'user/create', component: UserWizardComponent},
  { path: 'user/list', component: UserListComponent},
  { path: 'user/login', component: LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
