export class User {
    userName: string;
    userEmail: string;
    userPassword: string;
    userFirstName: string;
    userLastName: string;
    userAddress: string;
    userPhoneNumber: string;
}